/*package test;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

import org.junit.Test;
import parser.Parser;
import parser.EncodeTree;
public class ParserTest {
	private String[] testCommands = {
			
	};
	@Test
	public void testMath(){
		Parser p = new Parser("");
		try {
			EncodeTree testTree = p.encode("sum 4 4");
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void testLogic(){
		
	}
	
	@Test
	public void testControl(){
		
	}
	
	
}
*/