package parser.node;

/**
 * 
 * @author Junho Oh
 */
public class ValueNode extends Node{
	public ValueNode(int value) {
		setValue(value);
	}
}
