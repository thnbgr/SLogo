package parser.node.control;

import parser.node.Node;

public class IfElseNode extends Node {

	public IfElseNode() {
	}

}
