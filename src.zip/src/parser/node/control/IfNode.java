package parser.node.control;

import parser.node.Node;

public class IfNode extends Node {
	
}
