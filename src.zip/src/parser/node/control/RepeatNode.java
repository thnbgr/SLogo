package parser.node.control;

import parser.node.Node;

public class RepeatNode extends Node {

	public RepeatNode() {
	}
}
